
import React, { useState, useCallback } from 'react';
import { GoogleGenAI, Type, GenerateContentResponse } from '@google/genai';
import { SiteScanResult, PageScanResult, CheckItem, ChatMessage } from './types';
import Header from './components/Header';
import ScanForm from './components/ScanForm';
import LoadingSpinner from './components/LoadingSpinner';
import Alert from './components/Alert';
import ResultsDisplay from './components/ResultsDisplay';
import ChatbotWidget from './components/ChatbotWidget';
import { ai } from './lib/gemini';
import { WCAG_RULES } from './constants';
import { speak } from './lib/tts';

const App: React.FC = () => {
  const [scanResults, setScanResults] = useState<SiteScanResult[] | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [loadingMessage, setLoadingMessage] = useState('');

  const extractCleanDomain = (url: string): string => {
    try {
        const hostname = new URL(url).hostname;
        return hostname.replace(/^www\./, '');
    } catch (e) {
        const match = url.match(/(?:www\.)?([a-zA-Z0-9-]+\.[a-zA-Z]{2,})/);
        return match ? match[1] : url;
    }
  };

  const performAiScan = useCallback(async (scanUrl: string, numPages: number): Promise<SiteScanResult> => {
    const rulesString = JSON.stringify(WCAG_RULES.map(({ sc_id, ui_description }) => ({ sc_id, ui_description })));
    const prompt = `You are a simulated backend API for an expert ADA compliance scanner. Your task is to act as if you have crawled and analyzed the website "${scanUrl}".

**Instructions:**
1.  **Crawl**: Generate a list of ${numPages} plausible internal page URLs from this domain (e.g., homepage, about, contact).
2.  **Analyze**: For each of these ${numPages} pages, perform a detailed, rule-based ADA compliance analysis against the provided ruleset. For each rule, determine a plausible status: "Pass", "Fail", or "Not Applicable".
3.  **Summarize per Page**: For each page, calculate a summary (passed, failed, score).
4.  **Summarize Overall**: Calculate an overall compliance score for the entire site (average of page scores).
5.  **Respond**: Return a single JSON object that strictly adheres to the provided schema. Do not add extra explanations.

**Ruleset:**
${rulesString}`;

    const pageReportSchema = {
        type: Type.OBJECT,
        properties: {
            url: { type: Type.STRING },
            page_title: { type: Type.STRING },
            results: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        CHECK_ID: { type: Type.STRING },
                        ISSUE_STATUS: { type: Type.STRING, enum: ["Pass", "Fail", "Not Applicable"] },
                    },
                    required: ["CHECK_ID", "ISSUE_STATUS"]
                }
            },
            summary: {
                type: Type.OBJECT,
                properties: {
                    passed: { type: Type.INTEGER },
                    failed: { type: Type.INTEGER },
                    compliance_score: { type: Type.INTEGER }
                },
                required: ["passed", "failed", "compliance_score"]
            }
        },
        required: ["url", "page_title", "results", "summary"]
    };

    const schema = {
      type: Type.OBJECT,
      properties: {
        overall_score: { type: Type.INTEGER },
        page_reports: {
            type: Type.ARRAY,
            description: `An array of full report objects for exactly ${numPages} pages.`,
            items: pageReportSchema
        }
      },
      required: ["overall_score", "page_reports"]
    };

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { role: 'user', parts: [{ text: prompt }] },
        config: {
          responseMimeType: 'application/json',
          responseSchema: schema,
        },
    });
      
    const resultText = response.text.trim();
    const parsedResult = JSON.parse(resultText);
      
    const processedPageReports: PageScanResult[] = parsedResult.page_reports.map((report: any) => {
        const enrichedResults: CheckItem[] = report.results.map((item: any) => {
            const rule = WCAG_RULES.find(r => r.sc_id === item.CHECK_ID);
            return {
                ...item,
                CHECK_NAME: rule?.ui_description || 'Unknown Rule',
                FIX_RECOMMENDATION: rule?.fix_tip || 'No recommendation available.'
            };
        });
        return {
            ...report,
            scan_date: new Date().toISOString(),
            results: enrichedResults,
            summary: {
                ...report.summary,
                total_checks: WCAG_RULES.length
            }
        };
    });

    return {
        input_url: scanUrl,
        pages_analyzed: processedPageReports.length,
        overall_score: parsedResult.overall_score,
        page_reports: processedPageReports
    };
  }, []);

  const handleScan = useCallback(async (scanUrlInput: string, numPages: number) => {
    const urls = scanUrlInput.split(/[\n,]+/).map(u => u.trim()).filter(Boolean);
    
    if (urls.length === 0) {
      setError('Please enter at least one website URL.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setScanResults(null);
    setLoadingMessage('Validating URLs...');

    const validationPromises = urls.map(async (url) => {
        const urlRegex = /^(?:https?:\/\/)?(?:www\.)?([a-zA-Z0-9-]+\.){1,}[a-zA-Z]{2,}(?:\/\S*)?$/;
        if (!urlRegex.test(url)) throw new Error(`Invalid URL format: ${url}`);
        let normalizedUrl = url;
        if (!/^https?:\/\//i.test(url)) normalizedUrl = `https://${url}`;
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 20000);
        await fetch(normalizedUrl, { method: 'HEAD', mode: 'no-cors', signal: controller.signal });
        clearTimeout(timeoutId);
        return normalizedUrl;
    });

    const validationResults = await Promise.allSettled(validationPromises);
    const validUrls: string[] = [];
    const failedUrls: string[] = [];
    validationResults.forEach((res, i) => {
        if (res.status === 'fulfilled') {
            validUrls.push(res.value);
        } else {
            failedUrls.push(urls[i]);
        }
    });

    if (failedUrls.length > 0) {
        speak("Invalid URL, try again.");
        setError(`Failed to scan ${failedUrls.length} URL(s). Please check the URLs and try again.`);
    }

    if (validUrls.length === 0) {
        setIsLoading(false);
        return;
    }

    if (validUrls.length === 1) {
        const cleanDomain = extractCleanDomain(validUrls[0]);
        speak(`Welcome! Now you are here to check ADA compliance for ${cleanDomain}.`);
    } else {
        speak(`Beginning scan for ${validUrls.length} websites.`);
    }
    await new Promise(resolve => setTimeout(resolve, 1000));

    setLoadingMessage(`Scanning ${validUrls.length} website${validUrls.length > 1 ? 's' : ''} for ADA compliance...`);
    const scanPromises = validUrls.map(url => performAiScan(url, numPages));
    const settledScanResults = await Promise.allSettled(scanPromises);

    const successfulScans: SiteScanResult[] = [];
    settledScanResults.forEach(res => {
        if (res.status === 'fulfilled') {
            successfulScans.push(res.value);
        } else {
            console.error("An AI scan failed:", res.reason);
        }
    });

    if (successfulScans.length > 0) {
        setScanResults(successfulScans);
        if (successfulScans.length === 1) {
            const result = successfulScans[0];
            const cleanDomain = extractCleanDomain(result.input_url);
            speak(`ADA check completed for ${cleanDomain} — Compliance score ${result.overall_score} percent.`);
        } else if (successfulScans.length > 1) {
            speak(`ADA check completed for ${successfulScans.length} websites.`);
        }
    }

    setIsLoading(false);
  }, [performAiScan]);

  const getChatbotReply = async (history: ChatMessage[], scanContext: SiteScanResult[] | null): Promise<string> => {
    let contextPrompt = "The user has not performed a scan yet.";
    if (scanContext && scanContext.length > 0) {
        contextPrompt = "The user has the following ADA scan results available:\n\n";
        scanContext.forEach(site => {
            contextPrompt += `Site: ${site.input_url}\n`;
            contextPrompt += `Overall Score: ${site.overall_score}%\n`;
            site.page_reports.forEach(page => {
                const failedChecks = page.results.filter(r => r.ISSUE_STATUS === 'Fail').map(r => r.CHECK_NAME).join(', ') || 'None';
                contextPrompt += `- Page: ${page.url} (Score: ${page.summary.compliance_score}%) failed the following checks: ${failedChecks}.\n`;
            });
            contextPrompt += "\n";
        });
    }

    const systemInstruction = `You are a friendly and helpful ADA Accessibility Assistant. Your knowledge is strictly limited to website accessibility under the Americans with Disabilities Act (ADA) in the United States. Do not discuss WCAG unless specifically asked how it relates to ADA. Your tone should be encouraging and easy to understand for non-experts. Keep responses concise and helpful. Use the provided scan results context to answer user questions accurately. If the user asks a question unrelated to ADA or the provided scan results, politely decline to answer.`;

    const fullPrompt = `${contextPrompt}\n\nBased on the conversation history and the scan results context above, provide a helpful and conversational response to the user's latest message.\n\n${history.map(m => `${m.sender}: ${m.text}`).join('\n')}`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { role: 'user', parts: [{ text: fullPrompt }] },
            config: {
                systemInstruction: systemInstruction,
            }
        });
        return response.text;
    } catch (error) {
        console.error("Chatbot API error:", error);
        return "I'm sorry, I'm having trouble connecting right now. Please try again later.";
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-5xl">
                Ensure Your Website Meets ADA Compliance Standards
            </h2>
            <p className="mt-4 text-xl text-gray-600">
                Scan multiple websites for ADA compliance. Our AI-powered scanner analyzes accessibility issues and provides actionable recommendations.
            </p>
            <ScanForm onScan={handleScan} isLoading={isLoading} />
        </div>

        <div className="mt-8 max-w-6xl mx-auto">
            {isLoading && <LoadingSpinner message={loadingMessage} />}
            {error && <Alert message={error} />}
            {scanResults && <ResultsDisplay results={scanResults} />}
        </div>
      </main>
      <footer className="text-center py-4 text-gray-500 text-sm mt-8">
        <p>&copy; {new Date().getFullYear()} ADA Accessibility Checker. All rights reserved.</p>
      </footer>
      <ChatbotWidget scanResults={scanResults} getReply={getChatbotReply} />
    </div>
  );
};

export default App;
