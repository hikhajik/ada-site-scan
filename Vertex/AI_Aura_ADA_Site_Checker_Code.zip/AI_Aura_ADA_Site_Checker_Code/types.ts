
export type IssueStatus = "Pass" | "Fail" | "Not Applicable";

export interface CheckItem {
  CHECK_ID: string;
  CHECK_NAME: string;
  ISSUE_STATUS: IssueStatus;
  FIX_RECOMMENDATION: string;
}

export interface ScanSummary {
  total_checks: number;
  passed: number;
  failed: number;
  compliance_score: number;
}

export interface PageScanResult {
  url: string;
  page_title: string;
  scan_date: string;
  results: CheckItem[];
  summary: ScanSummary;
}

export interface SiteScanResult {
    input_url: string;
    pages_analyzed: number;
    overall_score: number;
    page_reports: PageScanResult[];
}

export interface ChatMessage {
  sender: 'user' | 'bot';
  text: string;
}
