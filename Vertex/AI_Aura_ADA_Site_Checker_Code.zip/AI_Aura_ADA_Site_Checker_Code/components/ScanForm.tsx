
import React, { useState } from 'react';

interface ScanFormProps {
  onScan: (url: string, numPages: number) => void;
  isLoading: boolean;
}

const ScanForm: React.FC<ScanFormProps> = ({ onScan, isLoading }) => {
  const [url, setUrl] = useState('');
  const [numPages, setNumPages] = useState(3);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onScan(url, numPages);
  };

  return (
    <form onSubmit={handleSubmit} className="mt-8 max-w-xl mx-auto flex flex-col gap-4">
      <div>
        <label htmlFor="url-input" className="sr-only">
          Website URLs
        </label>
        <textarea
          id="url-input"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="flex-grow w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-y"
          placeholder="Enter one or more URLs, separated by commas or new lines"
          disabled={isLoading}
          aria-label="Website URL Input"
          rows={3}
        />
      </div>
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="w-full sm:w-auto sm:flex-grow">
          <label htmlFor="pages-to-scan" className="block text-sm font-medium text-gray-700 mb-1">
            Pages to Crawl per Site: <span className="font-bold text-blue-600">{numPages}</span>
          </label>
          <input
            id="pages-to-scan"
            type="range"
            min="2"
            max="5"
            value={numPages}
            onChange={(e) => setNumPages(Number(e.target.value))}
            disabled={isLoading}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            aria-label={`Select number of pages to scan, currently ${numPages}`}
          />
        </div>
        <button
          type="submit"
          className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors self-end"
          disabled={isLoading}
          aria-busy={isLoading}
        >
          {isLoading ? 'SCANNING...' : 'SCAN'}
        </button>
      </div>
    </form>
  );
};

export default ScanForm;
