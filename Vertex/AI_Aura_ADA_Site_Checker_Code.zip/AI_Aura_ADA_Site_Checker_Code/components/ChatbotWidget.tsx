
import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, SiteScanResult } from '../types';
import { speak } from '../lib/tts';
import { useSpeechRecognition } from '../hooks/useSpeechRecognition';
import { ChatIcon, CloseIcon, MicrophoneIcon, SendIcon } from './icons';

interface ChatbotWidgetProps {
    scanResults: SiteScanResult[] | null;
    getReply: (history: ChatMessage[], scanContext: SiteScanResult[] | null) => Promise<string>;
}

const ChatbotWidget: React.FC<ChatbotWidgetProps> = ({ scanResults, getReply }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [inputValue, setInputValue] = useState('');
    const [isBotTyping, setIsBotTyping] = useState(false);
    const [isMuted, setIsMuted] = useState(false);

    const chatboxRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLInputElement>(null);
    const chatButtonRef = useRef<HTMLButtonElement>(null);

    // Load state from localStorage on initial mount
    useEffect(() => {
        try {
            const storedMessages = localStorage.getItem('chatHistory');
            if (storedMessages) {
                setMessages(JSON.parse(storedMessages));
            }

            const storedMuteState = localStorage.getItem('chatMuted');
            if (storedMuteState) {
                setIsMuted(JSON.parse(storedMuteState));
            }
        } catch (error) {
            console.error("Failed to parse state from localStorage", error);
        }
    }, []);

    // Persist messages to localStorage
    useEffect(() => {
        try {
            localStorage.setItem('chatHistory', JSON.stringify(messages));
        } catch (error) {
            console.error("Failed to save chat history to localStorage", error);
        }
    }, [messages]);

    // Persist mute state to localStorage
    useEffect(() => {
        try {
            localStorage.setItem('chatMuted', JSON.stringify(isMuted));
        } catch (error) {
            console.error("Failed to save mute state to localStorage", error);
        }
    }, [isMuted]);


    const handleVoiceResult = (transcript: string) => {
        setInputValue(transcript);
        sendMessage(transcript);
    };

    const { isListening, startListening, stopListening, isSpeechSupported } = useSpeechRecognition(handleVoiceResult);

    useEffect(() => {
        if (isOpen) {
            if (messages.length === 0) {
                const initialBotMessage = scanResults
                    ? `I see you've completed a scan. Ask me anything about the results!`
                    : "Welcome! I can help you understand ADA website compliance. How can I assist you?";
                const botMessage: ChatMessage = { sender: 'bot', text: initialBotMessage };
                setMessages([botMessage]);
                if (!isMuted) speak(initialBotMessage);
            }
            inputRef.current?.focus();
        } else {
            chatButtonRef.current?.focus();
        }
    }, [isOpen, scanResults, isMuted]); // Rerun if isMuted changes while closed

    useEffect(() => {
        chatboxRef.current?.scrollTo(0, chatboxRef.current.scrollHeight);
    }, [messages, isBotTyping]);
    
    useEffect(() => {
        const handleEsc = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                setIsOpen(false);
            }
        };
        window.addEventListener('keydown', handleEsc);
        return () => window.removeEventListener('keydown', handleEsc);
    }, []);

    const sendMessage = async (text: string) => {
        const userMessage = text.trim();
        if (!userMessage) return;

        const newMessages: ChatMessage[] = [...messages, { sender: 'user', text: userMessage }];
        setMessages(newMessages);
        setInputValue('');
        setIsBotTyping(true);

        const botReplyText = await getReply(newMessages, scanResults);
        
        setMessages(prev => [...prev, { sender: 'bot', text: botReplyText }]);
        if (!isMuted) speak(botReplyText);
        setIsBotTyping(false);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        sendMessage(inputValue);
    };

    const handleClose = () => {
        const shouldClear = window.confirm("Do you want to clear the chat history?");
        if (shouldClear) {
            setMessages([]);
        }
        setIsOpen(false);
    };

    if (!isOpen) {
        return (
            <button
                ref={chatButtonRef}
                onClick={() => setIsOpen(true)}
                className="fixed bottom-5 right-5 bg-blue-600 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-transform hover:scale-110"
                aria-label="Open ADA Assistant Chat"
            >
                <ChatIcon />
            </button>
        );
    }

    return (
        <div role="dialog" aria-modal="true" aria-labelledby="chat-header" className="fixed bottom-5 right-5 w-[90vw] max-w-md h-[70vh] max-h-[600px] flex flex-col bg-white rounded-lg shadow-2xl border border-gray-200 z-50">
            <header className="flex items-center justify-between p-2 pl-4 bg-blue-600 text-white rounded-t-lg">
                <h2 id="chat-header" className="text-lg font-semibold">AI Assistant</h2>
                <div className="flex items-center space-x-1">
                    <button onClick={() => setIsMuted(prev => !prev)} aria-label={isMuted ? "Unmute voice" : "Mute voice"} className="p-2 rounded-full hover:bg-blue-500 transition-colors">
                        {isMuted ? '🔇' : '🔊'}
                    </button>
                    <button onClick={() => setIsOpen(false)} aria-label="Minimize chat" className="p-2 rounded-full hover:bg-blue-500 transition-colors text-xl font-bold leading-none">
                        –
                    </button>
                    <button onClick={handleClose} aria-label="Close and clear chat history" className="p-2 rounded-full hover:bg-blue-500 transition-colors text-xl font-bold leading-none">
                        ✖
                    </button>
                </div>
            </header>

            <div ref={chatboxRef} className="flex-1 p-4 overflow-y-auto space-y-4">
                {messages.map((msg, index) => (
                    <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-xs lg:max-w-sm px-4 py-2 rounded-2xl ${msg.sender === 'user' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-800'}`}>
                            <p>{msg.text}</p>
                        </div>
                    </div>
                ))}
                {isBotTyping && (
                     <div className="flex justify-start">
                        <div className="bg-gray-200 text-gray-800 px-4 py-2 rounded-2xl flex items-center space-x-1">
                           <span className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-0"></span>
                           <span className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-150"></span>
                           <span className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-300"></span>
                        </div>
                    </div>
                )}
                 <div aria-live="polite" className="sr-only">
                    {messages.length > 0 && messages[messages.length - 1].sender === 'bot' && !isMuted && messages[messages.length - 1].text}
                </div>
            </div>

            <form onSubmit={handleSubmit} className="p-4 border-t bg-white rounded-b-lg flex items-center gap-2">
                <input
                    ref={inputRef}
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    className="flex-grow w-full px-4 py-2 border border-gray-300 rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Ask about the results..."
                    aria-label="Chat message input"
                />
                {isSpeechSupported && (
                    <button
                        type="button"
                        onClick={isListening ? stopListening : startListening}
                        className={`p-2 rounded-full transition-colors ${isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-gray-200 text-gray-600 hover:bg-gray-300'}`}
                        aria-label={isListening ? 'Stop listening' : 'Start voice input'}
                    >
                        <MicrophoneIcon className="h-5 w-5" />
                    </button>
                )}
                <button type="submit" className="p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500" aria-label="Send message">
                    <SendIcon />
                </button>
            </form>
        </div>
    );
};

export default ChatbotWidget;
