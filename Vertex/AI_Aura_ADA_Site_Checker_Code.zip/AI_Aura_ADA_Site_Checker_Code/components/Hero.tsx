
import React from 'react';

const Hero: React.FC = () => {
  return (
    <>
      <h2 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-5xl">
        Ensure Your Website Meets ADA Compliance Standards
      </h2>
      <p className="mt-4 text-xl text-gray-600">
        Our AI-powered accessibility scanner identifies ADA compliance issues and provides actionable recommendations to make your website accessible to everyone.
      </p>
    </>
  );
};

export default Hero;
