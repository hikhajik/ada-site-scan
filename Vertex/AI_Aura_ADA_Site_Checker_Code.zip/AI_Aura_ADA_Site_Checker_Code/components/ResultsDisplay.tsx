
import React, { useState } from 'react';
import { SiteScanResult } from '../types';
import SingleSiteReport from './SingleSiteReport';
import { generateCombinedPdfReport } from '../lib/pdfGenerator'; 
import EmailReportModal from './EmailReportModal';
import { EmailIcon } from './icons';

const ResultsDisplay: React.FC<{ results: SiteScanResult[] }> = ({ results }) => {
    const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);

    const handleSendCombinedReport = async (email: string) => {
        console.log("Simulating sending combined report to:", email);
        console.log("Data:", results);
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));
        if (Math.random() > 0.1) { // 90% success rate
            return "Combined report sent successfully!";
        } else {
            throw new Error("Failed to send email. Please try again later.");
        }
    };

    return (
        <div className="space-y-12 animate-fade-in">
            <div className="text-center flex flex-col sm:flex-row items-center justify-center gap-4">
                 <button
                    onClick={() => generateCombinedPdfReport(results)}
                    className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors"
                >
                    Download Combined PDF Report
                </button>
                <button
                    onClick={() => setIsEmailModalOpen(true)}
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-gray-700 hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-colors"
                >
                    <EmailIcon />
                    Email Combined Report
                </button>
            </div>
            {results.map((result, index) => (
                <SingleSiteReport key={index} result={result} />
            ))}
            <EmailReportModal 
                isOpen={isEmailModalOpen}
                onClose={() => setIsEmailModalOpen(false)}
                onSend={handleSendCombinedReport}
                reportTitle="Combined Summary"
            />
        </div>
    );
};

export default ResultsDisplay;
