
import React from 'react';

interface LoadingSpinnerProps {
    message?: string;
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ message }) => {
  return (
    <div className="flex flex-col items-center justify-center p-10">
      <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
      <p className="mt-4 text-lg font-semibold text-gray-600">{message || 'Analyzing accessibility...'}</p>
      <p className="mt-1 text-sm text-gray-500">This may take a moment.</p>
    </div>
  );
};

export default LoadingSpinner;
