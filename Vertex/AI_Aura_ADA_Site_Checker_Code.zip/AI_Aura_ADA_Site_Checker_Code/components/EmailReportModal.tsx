
import React, { useState, useRef, useEffect } from 'react';
import { CloseIcon } from './icons';

interface EmailReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSend: (email: string) => Promise<string>;
  reportTitle: string;
}

const EmailReportModal: React.FC<EmailReportModalProps> = ({ isOpen, onClose, onSend, reportTitle }) => {
  const [email, setEmail] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      // Reset state when modal opens
      setEmail('');
      setError(null);
      setSuccessMessage(null);
      setIsSending(false);
    }
  }, [isOpen]);

  const handleSend = async () => {
    setError(null);
    setSuccessMessage(null);

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError("Please enter a valid email address.");
      return;
    }

    setIsSending(true);
    try {
      const message = await onSend(email);
      setSuccessMessage(message);
      setTimeout(() => {
        onClose();
      }, 2000); // Close modal after 2 seconds on success
    } catch (e: any) {
      setError(e.message || "An unknown error occurred.");
    } finally {
      setIsSending(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
      role="dialog"
      aria-modal="true"
      aria-labelledby="email-modal-title"
    >
      <div ref={modalRef} className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md m-4">
        <div className="flex justify-between items-center mb-4">
          <h2 id="email-modal-title" className="text-xl font-bold text-gray-800">Email Report</h2>
          <button onClick={onClose} aria-label="Close modal">
            <CloseIcon />
          </button>
        </div>
        <p className="text-gray-600 mb-4">Enter the email address to send the report for <span className="font-semibold">{reportTitle}</span>.</p>
        
        <div className="space-y-4">
          <div>
            <label htmlFor="email-address" className="sr-only">Email address</label>
            <input
              type="email"
              id="email-address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              disabled={isSending}
            />
          </div>
          
          {error && <div className="text-red-600 text-sm">{error}</div>}
          {successMessage && <div className="text-green-600 text-sm">✅ {successMessage}</div>}

          <div className="flex justify-end space-x-3">
            <button 
              onClick={onClose}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors"
              disabled={isSending}
            >
              Cancel
            </button>
            <button
              onClick={handleSend}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:bg-gray-400"
              disabled={isSending}
            >
              {isSending ? 'Sending...' : 'Send'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailReportModal;
