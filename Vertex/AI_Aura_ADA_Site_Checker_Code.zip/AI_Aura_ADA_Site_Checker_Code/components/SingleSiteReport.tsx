
import React, { useState, useMemo } from 'react';
import { SiteScanResult, PageScanResult, CheckItem, IssueStatus } from '../types';
import ScoreCircle from './ScoreCircle';
import { generateSinglePagePdfReport } from '../lib/pdfGenerator';
import EmailReportModal from './EmailReportModal';
import { EmailIcon } from './icons';

const StatusBadge: React.FC<{ status: IssueStatus }> = ({ status }) => {
    const baseClasses = "px-2 inline-flex text-xs leading-5 font-semibold rounded-full";
    switch (status) {
        case 'Pass':
            return <span className={`${baseClasses} bg-green-100 text-green-800`}>Pass</span>;
        case 'Fail':
            return <span className={`${baseClasses} bg-red-100 text-red-800`}>Fail</span>;
        case 'Not Applicable':
            return <span className={`${baseClasses} bg-gray-100 text-gray-800`}>N/A</span>;
        default:
            return null;
    }
};

const InlinePageDetailView: React.FC<{ page: PageScanResult }> = ({ page }) => {
    const [filter, setFilter] = useState<'total' | 'failed' | 'passed'>('total');
    const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);

    const { totalChecks, failedCount, passedCount } = useMemo(() => {
        const failed = page.results.filter(item => item.ISSUE_STATUS === 'Fail').length;
        const passed = page.results.filter(item => item.ISSUE_STATUS === 'Pass').length;
        return {
            totalChecks: page.results.length,
            failedCount: failed,
            passedCount: passed,
        };
    }, [page.results]);

    const filteredResults = useMemo(() => {
        switch (filter) {
            case 'failed':
                return page.results.filter(item => item.ISSUE_STATUS === 'Fail');
            case 'passed':
                return page.results.filter(item => item.ISSUE_STATUS === 'Pass');
            case 'total':
            default:
                return page.results;
        }
    }, [filter, page.results]);

    const handleSendPageReport = async (email: string) => {
        console.log(`Simulating sending page report for ${page.url} to:`, email);
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));
        if (Math.random() > 0.1) { // 90% success rate
            return "Page report sent successfully!";
        } else {
            throw new Error("Failed to send email. Please try again later.");
        }
    };

    return (
        <div className="p-6 bg-white border-t border-gray-200 animate-fade-in">
            <div className="flex flex-col md:flex-row items-center gap-6 mb-6">
                {/* Score Circle */}
                <div className="flex-shrink-0 flex flex-col items-center">
                    <h4 className="text-lg font-semibold text-gray-700 mb-2">
                        Compliance Score
                    </h4>
                    <ScoreCircle score={page.summary.compliance_score} />
                </div>
                {/* Filter Buttons */}
                <div className="flex-grow flex flex-wrap items-center justify-center md:justify-start gap-3">
                    <button 
                        onClick={() => setFilter('total')}
                        className={`px-4 py-2 rounded-lg font-semibold text-white transition-colors text-sm ${filter === 'total' ? 'bg-blue-600 shadow-md' : 'bg-blue-500 hover:bg-blue-600'}`}
                    >
                        🟦 Total: {totalChecks}
                    </button>
                    <button 
                        onClick={() => setFilter('failed')}
                        className={`px-4 py-2 rounded-lg font-semibold text-white transition-colors text-sm ${filter === 'failed' ? 'bg-red-600 shadow-md' : 'bg-red-500 hover:bg-red-600'}`}
                    >
                        🟥 Failed: {failedCount}
                    </button>
                    <button 
                        onClick={() => setFilter('passed')}
                        className={`px-4 py-2 rounded-lg font-semibold text-white transition-colors text-sm ${filter === 'passed' ? 'bg-green-600 shadow-md' : 'bg-green-500 hover:bg-green-600'}`}
                    >
                        🟩 Passed: {passedCount}
                    </button>
                </div>
                 <div className="flex-shrink-0 flex flex-col sm:flex-row gap-2">
                     <button
                        onClick={() => generateSinglePagePdfReport(page)}
                        className="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors"
                    >
                        Download PDF
                    </button>
                    <button
                        onClick={() => setIsEmailModalOpen(true)}
                        className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-gray-700 hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-colors"
                    >
                        <EmailIcon className="h-4 w-4" /> Email Report
                    </button>
                </div>
            </div>

            <div>
                <h4 className="text-lg font-semibold text-gray-800 mb-2">Checkpoint Analysis</h4>
                <div className="overflow-x-auto border border-gray-200 rounded-lg">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-100">
                            <tr>
                                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Check Id</th>
                                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Check Name</th>
                                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Issue Status</th>
                                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fix Recommendation</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {filteredResults.map((item) => {
                                const statusClass = item.ISSUE_STATUS === 'Fail' ? 'bg-red-50' : item.ISSUE_STATUS === 'Pass' ? 'bg-green-50' : '';
                                return (
                                    <tr key={item.CHECK_ID} className={`${statusClass} transition-colors duration-300`}>
                                        <td className="px-4 py-4 whitespace-nowrap text-sm font-mono text-gray-500">{item.CHECK_ID}</td>
                                        <td className="px-4 py-4 whitespace-normal text-sm text-gray-800 font-medium">{item.CHECK_NAME}</td>
                                        <td className="px-4 py-4 whitespace-nowrap text-sm">
                                            <StatusBadge status={item.ISSUE_STATUS} />
                                        </td>
                                        <td className="px-4 py-4 whitespace-normal text-sm text-gray-600">
                                            {item.ISSUE_STATUS === 'Pass' ? 'N/A' : item.FIX_RECOMMENDATION}
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
            <EmailReportModal 
                isOpen={isEmailModalOpen}
                onClose={() => setIsEmailModalOpen(false)}
                onSend={handleSendPageReport}
                reportTitle={page.url}
            />
        </div>
    );
};


const SingleSiteReport: React.FC<{ result: SiteScanResult }> = ({ result }) => {
    const [selectedPageUrl, setSelectedPageUrl] = useState<string | null>(null);

    const handleSelectPage = (pageUrl: string) => {
        setSelectedPageUrl(prev => (prev === pageUrl ? null : pageUrl));
    };

    return (
        <div className="bg-white shadow-lg rounded-lg p-6 sm:p-8 border-t-4 border-blue-600">
            <header className="border-b pb-4 mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                    🌐 Website: <a href={result.input_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline break-all">{result.input_url}</a>
                </h2>
                <div className="flex flex-wrap gap-x-6 gap-y-2 text-md text-gray-600 mt-2">
                    <span>Pages Crawled: <span className="font-semibold">{result.pages_analyzed}</span></span>
                    <span>Overall ADA Compliance: <span className="font-bold text-lg">{result.overall_score}%</span></span>
                </div>
            </header>

            <section>
                <h3 className="text-lg font-semibold text-gray-700 mb-4">Crawled Page Summaries</h3>
                <div className="space-y-2">
                    {result.page_reports.map((page, index) => {
                        const isSelected = selectedPageUrl === page.url;
                        return (
                            <div key={index} className={`border rounded-lg transition-all duration-300 ${isSelected ? 'bg-blue-50 border-blue-300 shadow-md' : 'bg-gray-50 border-gray-200'}`}>
                                <button 
                                    onClick={() => handleSelectPage(page.url)} 
                                    className="w-full text-left p-4"
                                    aria-expanded={isSelected}
                                >
                                    <div className="flex justify-between items-center flex-wrap gap-2">
                                        <p className="font-bold text-blue-700 break-all flex items-center">
                                            <svg className={`w-5 h-5 mr-2 transform transition-transform duration-300 ${isSelected ? 'rotate-90' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path></svg>
                                            {page.url}
                                        </p>
                                        <div className="flex gap-4 text-sm flex-shrink-0 pl-6">
                                            <span>Score: <span className="font-bold">{page.summary.compliance_score}%</span></span>
                                            <span className="text-red-600">Failed: <span className="font-bold">{page.summary.failed}</span></span>
                                            <span className="text-green-600">Passed: <span className="font-bold">{page.summary.passed}</span></span>
                                        </div>
                                    </div>
                                </button>
                                {isSelected && <InlinePageDetailView page={page} />}
                            </div>
                        );
                    })}
                </div>
            </section>
        </div>
    );
};

export default SingleSiteReport;
