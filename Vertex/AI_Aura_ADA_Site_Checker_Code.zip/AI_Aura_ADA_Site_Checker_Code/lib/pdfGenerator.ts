
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { SiteScanResult, PageScanResult } from '../types';

const addFooter = (doc: jsPDF) => {
    const pageCount = doc.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(10);
        doc.text(`Page ${i} of ${pageCount}`, doc.internal.pageSize.width / 2, doc.internal.pageSize.height - 10, { align: 'center' });
    }
};

export const generateSinglePagePdfReport = (pageResult: PageScanResult) => {
    const doc = new jsPDF();

    // Header
    doc.setFontSize(22);
    doc.setFont('helvetica', 'bold');
    doc.text('ADA Page Scan Report', 14, 22);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text(`Page: ${pageResult.url}`, 14, 32);
    doc.text(`Scanned on: ${new Date(pageResult.scan_date).toLocaleString()}`, 14, 38);

    // Summary
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('Page Summary', 14, 55);
    const summaryText = `Compliance Score: ${pageResult.summary.compliance_score}%   |   Passed: ${pageResult.summary.passed}   |   Failed: ${pageResult.summary.failed}`;
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text(summaryText, 14, 65);

    // Checkpoint Table
    autoTable(doc, {
        startY: 75,
        head: [['CHECK ID', 'CHECK NAME', 'STATUS', 'RECOMMENDATION']],
        body: pageResult.results.map(item => [
            item.CHECK_ID,
            item.CHECK_NAME,
            item.ISSUE_STATUS,
            item.ISSUE_STATUS === 'Pass' ? 'N/A' : item.FIX_RECOMMENDATION
        ]),
        theme: 'striped',
        headStyles: { fillColor: [37, 99, 235] },
        columnStyles: {
            0: { cellWidth: 20 },
            1: { cellWidth: 60 },
            2: { cellWidth: 25 },
            3: { cellWidth: 'auto' }
        },
        didParseCell: (data) => {
            if (data.column.index === 2 && data.cell.section === 'body') {
                if (data.cell.raw === 'Fail') {
                    data.cell.styles.textColor = [220, 38, 38];
                } else if (data.cell.raw === 'Pass') {
                    data.cell.styles.textColor = [22, 163, 74];
                }
            }
        }
    });

    addFooter(doc);
    doc.save(`ADA_Report_${pageResult.url.replace(/https?:\/\//, '').replace(/\//g, '_')}.pdf`);
};

export const generateCombinedPdfReport = (siteResults: SiteScanResult[]) => {
    const doc = new jsPDF();
    let finalY = 0;

    doc.setFontSize(22);
    doc.setFont('helvetica', 'bold');
    doc.text('ADA Site Scan - Combined Report', 14, 22);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 32);
    finalY = 40;

    siteResults.forEach((result, index) => {
        if (index > 0) {
            doc.addPage();
            finalY = 20;
        }

        doc.setFontSize(18);
        doc.setFont('helvetica', 'bold');
        doc.text(`Website: ${result.input_url}`, 14, finalY);
        finalY += 8;
        doc.setFontSize(12);
        doc.setFont('helvetica', 'normal');
        doc.text(`Overall ADA Compliance: ${result.overall_score}%`, 14, finalY);
        finalY += 10;

        autoTable(doc, {
            head: [['Crawled Page', 'Score', 'Failed', 'Passed']],
            body: result.page_reports.map(page => [
                page.url,
                `${page.summary.compliance_score}%`,
                page.summary.failed,
                page.summary.passed
            ]),
            startY: finalY,
            theme: 'grid',
            headStyles: { fillColor: [37, 99, 235] },
        });
        finalY = (doc as any).lastAutoTable.finalY + 15;
    });

    addFooter(doc);
    doc.save('ADA_Combined_Report.pdf');
};
