
import { GoogleGenAI } from '@google/genai';

// Assume process.env.API_KEY is configured in the deployment environment.
const apiKey = process.env.API_KEY;

if (!apiKey) {
  // In a real app, you'd want to handle this more gracefully.
  // For this context, we'll throw an error to make it clear.
  throw new Error("API_KEY environment variable not set.");
}

export const ai = new GoogleGenAI({ apiKey, vertexai: true });
