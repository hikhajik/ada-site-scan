
let femaleVoice: SpeechSynthesisVoice | null = null;

const loadVoices = () => {
  if (!('speechSynthesis' in window)) {
    return;
  }
  const voices = window.speechSynthesis.getVoices();
  // Find a professional female voice. The names vary across browsers/OS.
  // Prioritize specific, high-quality voices first.
  femaleVoice =
    voices.find(voice => voice.name === 'Google UK English Female') ||
    voices.find(voice => voice.name === 'Microsoft Zira - English (United States)') ||
    voices.find(voice => voice.lang.startsWith('en-') && voice.name.includes('Female')) ||
    voices.find(voice => voice.lang.startsWith('en-') && voice.name.includes('Zira')) ||
    voices.find(voice => voice.lang.startsWith('en-') && voice.name.includes('Google')) ||
    voices.find(voice => voice.lang.startsWith('en-') && !voice.name.includes('Male')) ||
    null;
};

// Voices are loaded asynchronously.
if ('speechSynthesis' in window && window.speechSynthesis.onvoiceschanged !== undefined) {
  window.speechSynthesis.onvoiceschanged = loadVoices;
}
loadVoices(); // Initial attempt

export const speak = (text: string): void => {
  if (!('speechSynthesis' in window)) {
    console.warn('Speech Synthesis not supported in this browser.');
    return;
  }
  
  // Ensure voices are loaded if they weren't ready initially
  if (!femaleVoice) {
    loadVoices();
  }

  const utterance = new SpeechSynthesisUtterance(text);
  if (femaleVoice) {
    utterance.voice = femaleVoice;
  }
  utterance.rate = 0.95; // A clear, friendly pace
  utterance.pitch = 1.1; // Slightly higher pitch for clarity

  // Cancel any ongoing speech to prevent overlap
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(utterance);
};
